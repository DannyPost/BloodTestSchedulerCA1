/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bloodtestscheduler;

/**
 *
 * @author bogda
 */
public class BloodTestSchedulerApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GUI guiGUI = new GUI();
        guiGUI.setVisible(true);
        
        
       /*BloodTestScheduler scheduler = new BloodTestScheduler();

        scheduler.addPatient("Alice", 65, "urgent", true, "Dr. Murphy");
        scheduler.addPatient("Bob", 50, "medium", false, "Dr. Kelly");
        scheduler.addPatient("Charlie", 40, "low", false, "Dr. Smith");
        scheduler.addPatient("David", 70, "urgent", false, "Dr. O'Brien");
        scheduler.addPatient("Eve", 55, "medium", true, "Dr. Brown");

        scheduler.displayAllPatients();

        System.out.println("\nNext patient: " + scheduler.getNextPatient());

        scheduler.markNoShow(new Patient("Frank", 45, "low", false, "Dr. Jones"));
        scheduler.markNoShow(new Patient("Grace", 38, "medium", false, "Dr. Black"));

        scheduler.displayNoShowPatients();

        System.out.println("\nRemaining patients:");
        Patient next;
        while ((next = scheduler.getNextPatient()) != null) {
            System.out.println(next);
        }*/
    }
    
}
